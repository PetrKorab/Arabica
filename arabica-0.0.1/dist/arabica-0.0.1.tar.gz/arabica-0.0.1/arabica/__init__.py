__version__ = "0.0.8"


from .arabica_freq import *
